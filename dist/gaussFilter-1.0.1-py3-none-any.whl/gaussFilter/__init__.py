"""
gaussFilter

A package for applying Gaussian filter to images.
"""

from .gaussFilter import apply_gaussian_filter